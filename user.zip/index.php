<?php
    header('Location: regiss.php');
?>